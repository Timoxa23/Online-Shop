package com.example.project1762.Helper

interface ChangeNumberItemsListener {
    fun onChanged() // Function name changed to follow Kotlin conventions
}