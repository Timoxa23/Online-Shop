package com.example.onlineshop.Activity

import android.content.Intent
import android.os.Bundle
import com.example.onlineshop.databinding.ActivityIntroBinding

class ActivityIntro : BaseActivity() {
    private lateinit var binding: ActivityIntroBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.apply {
            startBtn.setOnClickListener {
                startActivity(Intent(this@ActivityIntro, LoginActivity::class.java))
            }
        }
        binding.introSignInTxt.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
            finish()
        }
    }
}