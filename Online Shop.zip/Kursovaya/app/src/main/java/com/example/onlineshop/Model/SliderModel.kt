package com.example.onlineshop.Model

data class SliderModel(val url:String="")
