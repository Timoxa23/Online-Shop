pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
    plugins {
        id("com.android.application") version "7.0.2"
        id("org.jetbrains.kotlin.android") version "1.5.21"
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "OnlineShop"
include(":app")


rootProject.name = "Online Shop"
include(":app")
 